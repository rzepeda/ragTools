"""Repositories package for RAG Factory.

This package will contain repository implementations for:
- Vector stores
- Document stores
- Other data persistence layers
"""

__all__: list[str] = []
