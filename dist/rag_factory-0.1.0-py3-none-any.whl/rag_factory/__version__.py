"""Version information for rag-factory."""

__version__ = "0.1.0"
